import json
import boto3
from datetime import datetime
import uuid
from decimal import Decimal

# DynamoDB 설정
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
conversations_table = dynamodb.Table('nx-tt-dev-ver3-conversations')

# Decimal 타입을 JSON 직렬화 가능한 타입으로 변환
def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_float(item) for item in obj]
    return obj

# 응답 헤더 설정 (Lambda Function URL이 CORS를 자동 처리하므로 중복 제거)
def get_response_headers():
    return {
        'Content-Type': 'application/json'
    }

def lambda_handler(event, context):
    """
    대화 데이터 저장/조회 Lambda 핸들러
    """
    print(f"Event: {json.dumps(event)}")
    
    # Lambda Function URL 형식 처리
    if 'requestContext' in event and 'http' in event['requestContext']:
        # Function URL 형식
        method = event['requestContext']['http']['method']
        path = event['requestContext']['http']['path']
    else:
        # API Gateway 형식
        method = event.get('httpMethod', 'GET')
        path = event.get('path', '')
    
    # OPTIONS 요청 처리 (Lambda Function URL이 자동 처리하므로 간단히)
    if method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': get_response_headers(),
            'body': json.dumps({'message': 'OK'})
        }
    
    try:
        
        # POST / 또는 /conversations - 새 대화 저장 또는 업데이트
        if method == 'POST' and (path == '/' or path == '/conversations'):
            body = json.loads(event.get('body', '{}'))
            
            # 필수 필드 검증
            if not body.get('messages'):
                return {
                    'statusCode': 400,
                    'headers': get_response_headers(),
                    'body': json.dumps({'error': 'messages field is required'})
                }
            
            # 대화 ID 생성 또는 사용
            conversation_id = body.get('conversationId') or str(uuid.uuid4())
            
            # DynamoDB에 저장
            item = {
                'conversationId': conversation_id,
                'messages': body['messages'],
                'engineType': body.get('engineType', 'T5'),
                'title': body.get('title', 'New Conversation'),
                'createdAt': body.get('createdAt', datetime.now().isoformat()),
                'updatedAt': datetime.now().isoformat(),
                'metadata': body.get('metadata', {})
            }
            
            conversations_table.put_item(Item=item)
            
            return {
                'statusCode': 200,
                'headers': get_response_headers(),
                'body': json.dumps({
                    'conversationId': conversation_id,
                    'message': 'Conversation saved successfully'
                })
            }
        
        # GET /{id} 또는 /conversations/{id} - 특정 대화 조회
        elif method == 'GET' and ('/' in path and path != '/' and path != '/conversations'):
            conversation_id = path.split('/')[-1]
            
            response = conversations_table.get_item(
                Key={'conversationId': conversation_id}
            )
            
            if 'Item' not in response:
                return {
                    'statusCode': 404,
                    'headers': get_response_headers(),
                    'body': json.dumps({'error': 'Conversation not found'})
                }
            
            return {
                'statusCode': 200,
                'headers': get_response_headers(),
                'body': json.dumps(decimal_to_float(response['Item']))
            }
        
        # GET / 또는 /conversations - 모든 대화 목록 조회
        elif method == 'GET' and (path == '/' or path == '/conversations'):
            response = conversations_table.scan(
                ProjectionExpression='conversationId, title, engineType, createdAt, updatedAt'
            )
            
            conversations = response.get('Items', [])
            
            # 최신순 정렬
            conversations.sort(key=lambda x: x.get('updatedAt', ''), reverse=True)
            
            return {
                'statusCode': 200,
                'headers': get_response_headers(),
                'body': json.dumps({
                    'conversations': decimal_to_float(conversations),
                    'count': len(conversations)
                })
            }
        
        # DELETE /{id} 또는 /conversations/{id} - 대화 삭제
        elif method == 'DELETE' and ('/' in path and path != '/' and path != '/conversations'):
            conversation_id = path.split('/')[-1]
            
            conversations_table.delete_item(
                Key={'conversationId': conversation_id}
            )
            
            return {
                'statusCode': 200,
                'headers': get_response_headers(),
                'body': json.dumps({
                    'message': 'Conversation deleted successfully'
                })
            }
        
        else:
            return {
                'statusCode': 404,
                'headers': get_response_headers(),
                'body': json.dumps({'error': 'Not Found'})
            }
            
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': get_response_headers(),
            'body': json.dumps({'error': str(e)})
        }